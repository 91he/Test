#ifndef FORM_CHECK_H
#define FORM_CHECK_H

int pwd_check(const char *str);

int mail_check(const char *str);
#endif
