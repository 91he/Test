?package(usermanage-client):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="usermanage-client" command="/usr/bin/usermanage-client"
