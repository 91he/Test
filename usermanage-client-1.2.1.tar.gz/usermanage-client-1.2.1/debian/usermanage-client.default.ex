# Defaults for usermanage-client initscript
# sourced by /etc/init.d/usermanage-client
# installed at /etc/default/usermanage-client by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
