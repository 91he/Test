#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include "pool.h"
#include "curl_url.h"
#include "npp_funcs.h"
#include "npn_funcs.h"

GtkWidget *main_window = NULL;
struct thread_pool *g_pool = NULL;

#if 0
static NPWindow *npwindow_construct(GtkWidget *widget, uint32_t width, uint32_t height){
    NPWindow *npwindow;
    NPSetWindowCallbackStruct *ws_info;
    GtkWidget *socket= gtk_socket_new();
    GdkWindow *parent_win = gtk_widget_get_window(widget);

    gtk_widget_set_parent_window(socket, parent_win);

    //g_signal_connect(socket, "plug_removed", G_CALLBACK(plug_removed_cb), NULL);
    //g_signal_connect(socket, "unrealize", G_CALLBACK(socket_unrealize_cb), NULL);
    //g_signal_connect(socket, "destroy", G_CALLBACK(gtk_widget_destroyed), &socket);

    gpointer user_data = NULL;
    gdk_window_get_user_data(parent_win, &user_data);

    GtkContainer *container = GTK_CONTAINER(user_data);
    gtk_container_add(container, socket);
    gtk_widget_realize(socket);
    //printf("%p, %p, %p\n", parent_win, user_data, container);

    GtkAllocation new_allocation;
    new_allocation.x = 0;
    new_allocation.y = 0;
    new_allocation.width = width;
    new_allocation.height = height;
    gtk_widget_size_allocate(socket, &new_allocation);

    gtk_widget_show(socket);
    gdk_flush();

    Window win = gtk_socket_get_id(socket);
    //GdkWindow *gwin = gdk_window_lookup(win);
    GdkWindow *gwin = gtk_widget_get_window(socket);
    //gdk_x11_window_lookup_for_display(disp, win);

    npwindow = (NPWindow*)malloc(sizeof(NPWindow));
    //npwindow->window = (void*)(unsigned long)win;
    npwindow->window = (void*)win;
    npwindow->x = 0;
    npwindow->y = 0;
    npwindow->width = width;
    npwindow->height = height;

    ws_info = (NPSetWindowCallbackStruct*)malloc(sizeof(NPSetWindowCallbackStruct));
    ws_info->type = NP_SETWINDOW;
    ws_info->display = gdk_x11_display_get_xdisplay(gdk_window_get_display(gwin));
    GdkVisual* gdkVisual = gdk_window_get_visual(gwin);
    ws_info->visual = gdk_x11_visual_get_xvisual(gdkVisual);
    ws_info->colormap = XDefaultColormapOfScreen(XDefaultScreenOfDisplay(ws_info->display));
    ws_info->depth = gdk_visual_get_depth(gdkVisual);

    npwindow->ws_info = ws_info;
    npwindow->type = NPWindowTypeWindow;

    return npwindow;
}
#else
static gboolean plug_removed_cb (GtkWidget *widget, gpointer data) {
    printf("[!] plug_removed_cb\n");
    return TRUE;
}
static void socket_unrealize_cb(GtkWidget *widget, gpointer data) {
    printf("[!] socket_unrealize_cb\n");
    //gtk_widget_unrealize(widget);
}
static NPWindow *npwindow_construct(GtkWidget *widget, unsigned int width, unsigned int height){
    NPWindow *npwindow;
    NPSetWindowCallbackStruct *ws_info = NULL;

    GdkWindow *parent_win = widget->window;

    GtkWidget *socketWidget = gtk_socket_new();
    gtk_widget_set_parent_window(socketWidget, parent_win);

    g_signal_connect(socketWidget, "plug_removed", G_CALLBACK(plug_removed_cb), NULL);
    g_signal_connect(socketWidget, "unrealize", G_CALLBACK(socket_unrealize_cb), NULL);
    g_signal_connect(socketWidget, "destroy", G_CALLBACK(gtk_widget_destroyed), &socketWidget);

    gpointer user_data = NULL;
    gdk_window_get_user_data(parent_win, &user_data);

    GtkContainer *container = GTK_CONTAINER(user_data);
    gtk_container_add(container, socketWidget);
    gtk_widget_realize(socketWidget);

    GtkAllocation new_allocation;
    new_allocation.x = 0;
    new_allocation.y = 0;
    new_allocation.width = width;
    new_allocation.height = height;
    gtk_widget_size_allocate(socketWidget, &new_allocation);

    gtk_widget_show(socketWidget);
    gdk_flush();

    GdkNativeWindow ww = gtk_socket_get_id(GTK_SOCKET(socketWidget));
    GdkWindow *w = gdk_window_lookup(ww);

    npwindow = (NPWindow*)malloc(sizeof(NPWindow));
    npwindow->window = (void*)(unsigned long)ww;
    npwindow->x = 0;
    npwindow->y = 0;
    npwindow->width = width;
    npwindow->height = height;

    ws_info = (NPSetWindowCallbackStruct*)malloc(sizeof(NPSetWindowCallbackStruct));
    ws_info->type = NP_SETWINDOW;
    ws_info->display = GDK_WINDOW_XDISPLAY(w);
    ws_info->colormap = GDK_COLORMAP_XCOLORMAP(gdk_drawable_get_colormap(w));
    GdkVisual* gdkVisual = gdk_drawable_get_visual(w);
    ws_info->visual = GDK_VISUAL_XVISUAL(gdkVisual);
    ws_info->depth = gdkVisual->depth;

    npwindow->ws_info = ws_info;
    npwindow->type = NPWindowTypeWindow;

    return npwindow;
}
#endif

int main(int argc, char **argv){
    int pid;
    if(argc != 2){
        printf("\tUSAGE: player url\n\turl: Video URL which consist of swf address and flashvars. \n");
        return -1;
    }
#if 0
    if(pid = fork()){//dad
        printf("%d: %d\n", getpid(), pid);
    }else{//son
#else
    {
#endif
        printf("%d: %d, %d\n", getpid(), pid, true);
        g_pool = pool_init(4);
        gtk_init(&argc, &argv);

        main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_window_set_decorated(GTK_WINDOW(main_window), FALSE);
        gtk_window_move(GTK_WINDOW(main_window), 300, 100);
        gtk_widget_realize(main_window);
        gtk_widget_show_all(main_window);
        g_signal_connect(main_window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

        NPWindow *np_win = npwindow_construct(main_window, 800, 500);
        NPP_t instance_t = {NULL};
        NPP instance = &instance_t;
        NPObject object;

        char *xargv[] = {"id", "allowFullScreen"};
        char *xargm[] = {"player", "true"};
        My_NPP_New("application/x-shockwave-flash", instance, NP_EMBED, sizeof(xargv)/sizeof(char*), xargv, xargm, 0);
        My_NPP_GetValue(instance, NPPVpluginScriptableNPObject, &object);
        My_NPP_SetWindow(instance, np_win);

#if 0
        fprintf(stderr, "structVersion: %x\n", object._class->structVersion);
        fprintf(stderr, "NPAlloc: %p\n", object._class->allocate);
        fprintf(stderr, "NPDealloc: %p\n", object._class->deallocate);
        fprintf(stderr, "NPInval: %p\n", object._class->invalidate);
        fprintf(stderr, "NPHasMtd: %p\n", object._class->hasMethod);
        fprintf(stderr, "NPInvoke: %p\n", object._class->invoke);
        fprintf(stderr, "NPIvkDft: %p\n", object._class->invokeDefault);
        fprintf(stderr, "NPHasProp: %p\n", object._class->hasProperty);
        fprintf(stderr, "NPGetProp: %p\n", object._class->getProperty);
        fprintf(stderr, "NPSetProp: %p\n", object._class->setProperty);
        fprintf(stderr, "NPRmProp: %p\n", object._class->removeProperty);
        fprintf(stderr, "NPEnum: %p\n", object._class->enumerate);
        fprintf(stderr, "NPConstruct: %p\n", object._class->construct);
#endif

        My_NPN_GetURLNotify(instance, argv[1], NULL, NULL);

        gtk_main();

        My_NPP_Destroy(instance, NULL);
        pool_destroy(g_pool);
    }

    return 0;
}
