#include "stdafx.h"
#include "SocketPipe.h"
#include "Log.h"

SocketPipe::SocketPipe(HANDLE serviceEvent, unsigned short port, string path)
	:serviceEvent(serviceEvent), path(path), port(port)
{
	int i;
	s = 0;
	pipe = INVALID_HANDLE_VALUE;
	readOverlap.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	writeOverlap.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	events[0] = readOverlap.hEvent;
	events[1] = serviceEvent;
	c2hBufferSize = 1024;
	c2hBuffer = (char*)malloc(c2hBufferSize);
	h2cBufferSize = 4096;
	h2cBuffer = (char*)malloc(h2cBufferSize);

	for (i = 0; i < MAX_FD; i++){
		socks[i] = 0;
	}
}

SocketPipe::~SocketPipe(){
	int i;

	isRunning = false;

	if (INVALID_HANDLE_VALUE != pipe)
		CloseHandle(pipe);
	CloseHandle(readOverlap.hEvent);
	CloseHandle(writeOverlap.hEvent);
	if (!s) closesocket(s);

	for (i = 0; i < MAX_FD; i++){
		if (!socks[i]) closesocket(socks[i]);
	}

	free(h2cBuffer);
	free(c2hBuffer);
}

int SocketPipe::build(){
	int ret = 0;
	WSAData wsaData;

	if (pipe != INVALID_HANDLE_VALUE) return 1;

	pipe = CreateFileA(path.c_str(),
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_OVERLAPPED,
		NULL);
	if (pipe == INVALID_HANDLE_VALUE){
		cout << "Invalid handle error! MAKE SURE U HAVE PERMISSON FOR THIS." << endl;
		return -1;
	}

	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0){
		cout << "WSAStartup failed." << endl;
		ret = -1;
		goto end;
	}

	s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s == INVALID_SOCKET){
		cout << "socket failed." << endl;
		ret = -1;
		goto end;
	}

	addr.sin_family = AF_INET;
	addr.sin_port = htons(port);
	inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

	ret = bind(s, (sockaddr*)&addr, sizeof(addr));
	if (ret != 0){
		cout << "bind failed." << endl;
		ret = -1;
		goto end2;
	}

	ret = listen(s, 10);
	if (ret != 0){
		cout << "listen failed." << endl;
		ret = -1;
	}
#if 0
	unsigned long arg = 1;
	ret = ioctlsocket(s, FIONBIO, &arg);
	if (ret != NO_ERROR){
		cout << "set socket non-blocking failed." << endl;
		return -1;
	}
#endif

	return ret;

end:
	CloseHandle(pipe);
end2:
	closesocket(s);

	return ret;
}

static void Reorder(SOCKET *socks, int num){
	int i, j;

	for (i = 0, j = 0; i < num; j++){
		if (!socks[j]) continue;
		socks[i++] = socks[j];
	}
}

static void SetFd(SOCKET *socks, fd_set *fd, int num){
	int i;
	for (i = 0; i < num; i++){
		FD_SET(socks[i], fd);
	}
}

DWORD WINAPI SocketPipe::threadProc(LPVOID parm){
	SocketPipe *sp = (SocketPipe*)parm;

	while (sp->isRunning){
		unsigned int len;
		unsigned int id = 0;
		if (sp->readPipe((char*)&len, sizeof(len)) <= 0) break;
		if (sp->readPipe((char*)id, sizeof(int)) <= 0) break;
		if (sp->c2hBufferSize < len){
			while ((sp->c2hBufferSize *= 2) < len);
			sp->c2hBuffer = (char*)realloc(sp->c2hBuffer, sp->c2hBufferSize);
		}
		if (sp->write(id, sp->c2hBuffer, len) <= 0) break;
	}

	sp->isRunning = false;

	return 0;
}

int SocketPipe::run(){
	int ret;
	int num = 0;
	fd_set fd;
	timeval tv;
	
	if (build() < 0) return -1;
	if (isRunning) return 1;

	isRunning = true;
	tv.tv_sec = 1;
	tv.tv_usec = 1;

	HANDLE thread = CreateThread(NULL, 0, &SocketPipe::threadProc, this, 0, NULL);
	
	while (WaitForSingleObject(serviceEvent, 0) != WAIT_OBJECT_0){
		int cur = num;
		FD_ZERO(&fd);
		FD_SET(s, &fd);
		SetFd(socks, &fd, cur);

		ret = select(0, &fd, NULL, NULL, &tv);
		if (ret < 0){
			break;
		}
		
		if (FD_ISSET(s, &fd) && cur < 10){
			ret = accept(s, NULL, 0);
			if (ret == SOCKET_ERROR){
				s = 0;
				break;
			}
			cout << "New client." << endl;
			
			socks[cur++] = ret;
		}

		for (int i = 0; i < num; i++){
			if (FD_ISSET(socks[i], &fd)){
				if (process(socks[i]) <= 0){
					socks[i] = 0;
					cur--;
				}
			}
		}

		Reorder(socks, cur);
		num = cur;
	}
	isRunning = false;

	return 0;
}

int SocketPipe::process(SOCKET sock){
	int ret;
	int len;

	if ((ret = read(sock, (char*)&len, sizeof(len))) <= 0)
		return ret;

	if (h2cBufferSize < len){
		while ((h2cBufferSize *= 2) < len);
		h2cBuffer = (char*)realloc(h2cBuffer, h2cBufferSize);
	}
	if ((ret = read(sock, (char*)h2cBuffer, len)) <= 0)
		return ret;

	int *id = (int*)h2cBuffer;
	*id = sock;

	if (ret = writePipe(h2cBuffer, len) <= 0)
		return ret;

	return len;
}

int SocketPipe::read(SOCKET sock, char *buf, int size){
	int n;
	int offset = 0;
	int len = size;

	do{
		n = recv(sock, buf + offset, len, 0);
		if (n <= 0) return n;
		offset += n;
		len -= n;
	} while (len);

	return size;
}

int SocketPipe::write(SOCKET sock, char *buf, int size){
	int n;
	int offset = 0;
	int len = size;

	do{
		n = send(sock, buf + offset, len, 0);
		if (n <= 0) return n;
		offset += n;
		len -= n;
	} while (len);

	return size;
}

int SocketPipe::readPipe(char *buf, int size){
	BOOL ret;
	DWORD n = 0;
	int offset = 0;
	DWORD len = size;

	do{
		ret = ReadFile(pipe, buf + offset, len, NULL, &readOverlap);
		if(!ret && (ERROR_IO_PENDING != GetLastError())) return 0;
		
		ret = WaitForMultipleObjects(2, events, false, INFINITE);
		if(ret != WAIT_OBJECT_0) return 0;

		if(!GetOverlappedResult(pipe, &readOverlap, &n, FALSE)) return 0;

		offset += n;
		len -= n;
	} while (len);

	return size;
}

int SocketPipe::writePipe(char *buf, int size){
	BOOL ret;
	DWORD n = 0;
	DWORD offset = 0;
	DWORD len = size;
	DWORD cur = 0;

	do{
		cur = len > 4096 ? 4096 : len;

		ret = WriteFile(pipe, buf + offset, cur, NULL, &writeOverlap);
		if(!ret && (ERROR_IO_PENDING != GetLastError())) return 0;
		if(WAIT_FAILED == WaitForSingleObject(writeOverlap.hEvent, INFINITE)) return 0;
		if(!GetOverlappedResult(pipe, &writeOverlap, &n, FALSE)) return 0;
		
		offset += n;
		len -= n;
	} while (len);

	return size;
}