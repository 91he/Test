#ifndef MYLOG_H
#define MYLOG_H
#include <stdio.h>

#define MyLog(...) \
	do{ \
		FILE *file = NULL; \
		fopen_s(&file, "E:\\log.txt", "a"); \
		fprintf(file, __VA_ARGS__); \
		fclose(file); \
	} while (0)

#endif