#ifndef SOCKET_PIPE_H
#define SOCKET_PIPE_H
#include <string>
#include <iostream>
#include <WinSock2.h>
#include <WS2tcpip.h>
//#include <winsock.h>

#define MAX_FD 10
#define PIPENAME "\\\\.\\Global\\com.redhat.spice.1"

#pragma comment(lib, "ws2_32.lib")

using namespace std;

class SocketPipe{
public:
	~SocketPipe();
	SocketPipe(HANDLE serviceEvent, unsigned short port = 1920, string path = PIPENAME);
	int run();
private:
	unsigned short port;
	bool isRunning;
	SOCKET s;
	SOCKET socks[MAX_FD];
	fd_set fd;
	HANDLE pipe;
	HANDLE serviceEvent;
	HANDLE events[2];
	OVERLAPPED readOverlap;
	OVERLAPPED writeOverlap;
	string path;
	char *c2hBuffer;
	unsigned int c2hBufferSize;
	char *h2cBuffer;
	unsigned int h2cBufferSize;
	struct sockaddr_in addr;
	int build();
	int process(SOCKET s);
	int readPipe(char *buf, int size);
	int writePipe(char *buf, int size);
	int read(SOCKET sock, char *buf, int size);
	int write(SOCKET sock, char *buf, int size);
	static DWORD WINAPI threadProc(LPVOID parm);
};
#endif